"""
============================================================
Module: logic_kb.py
Author: Smart Campus AI System
Description:
    Logic / Knowledge Base Module for the Smart Campus AI
    Decision Support and Automation System.

    Implements a forward-chaining rule engine over a
    First-Order Logic (FOL) inspired knowledge base.

    Responsibilities:
    - Store facts and rules about campus entities
    - Check user eligibility and role authorization
    - Entail new facts via inference rules
    - Act as a gatekeeper before CSP scheduling
    - Return a structured result including explanation chain
============================================================
"""

# ────────────────────────────────────────────────────────────────────────────
#  KNOWLEDGE BASE FACTS
# ────────────────────────────────────────────────────────────────────────────
#
# Facts are stored as a set of strings in predicate form, e.g.
#   "Teaches(DrKhan, AI)"
#   "Student(Ali)"
#   "EnrolledIn(Ali, AI)"
# ────────────────────────────────────────────────────────────────────────────

INITIAL_FACTS = {
    # Instructors
    "Teaches(DrKhan, AI)",
    "Teaches(DrKhan, ML)",
    "Teaches(ProfSarah, Networks)",
    "Teaches(DrAli, DataStructures)",

    # Students and their enrollment / prerequisites
    "Student(Ali)",
    "Student(Sara)",
    "Student(Tom)",
    "EnrolledIn(Ali, AI)",
    "EnrolledIn(Sara, ML)",
    "EnrolledIn(Tom, DataStructures)",
    "Completed(Ali, ProgrammingFundamentals)",
    "Completed(Sara, ProgrammingFundamentals)",

    # Lab authorized users (initial direct grants)
    "Enrolled(Ali, AI)",
    "Enrolled(Sara, ML)",

    # Staff
    "Staff(Hassan)",
    "Staff(Fatima)",

    # Maintenance clearance
    "HasClearance(Hassan, Maintenance)",
    "HasClearance(Fatima, Maintenance)",
}


# ────────────────────────────────────────────────────────────────────────────
#  INFERENCE RULES
# ────────────────────────────────────────────────────────────────────────────
#
# Each rule is a tuple: (preconditions_list, conclusion_template, description)
# We use simple string-matching on facts rather than a full unification engine.
# ────────────────────────────────────────────────────────────────────────────

def _extract(fact: str) -> tuple:
    """
    Extract predicate name and arguments from a fact string.
    E.g. "Teaches(DrKhan, AI)" -> ("Teaches", ["DrKhan", "AI"])
    """
    if "(" not in fact:
        return fact, []
    pred = fact[:fact.index("(")]
    args_str = fact[fact.index("(") + 1:fact.rindex(")")]
    args = [a.strip() for a in args_str.split(",")]
    return pred, args


def _match_facts(pattern: str, facts: set) -> list:
    """
    Return all facts that match a pattern.
    A '?' in an argument position acts as a wildcard.
    E.g. pattern "Teaches(?, AI)" matches "Teaches(DrKhan, AI)"
    Returns list of dicts {var_position: matched_value}
    """
    p_pred, p_args = _extract(pattern)
    matches = []
    for fact in facts:
        f_pred, f_args = _extract(fact)
        if f_pred != p_pred or len(f_args) != len(p_args):
            continue
        binding = {}
        ok = True
        for i, (pa, fa) in enumerate(zip(p_args, f_args)):
            if pa == "?":
                binding[i] = fa
            elif pa != fa:
                ok = False
                break
        if ok:
            matches.append(binding)
    return matches


class KnowledgeBase:
    """
    Rule-based knowledge base with forward chaining.
    """

    def __init__(self):
        self.facts = set(INITIAL_FACTS)
        self._run_forward_chain()

    def _run_forward_chain(self):
        """
        Run forward chaining until no new facts are derived.
        Rules:
          R1: Teaches(X, AI) => Instructor(X, AI)
          R2: Instructor(X, AI) => UsesLab(X, Lab1)
          R3: Enrolled(X, AI) => UsesLab(X, Lab1)
          R4: Student(X) & Completed(X, ProgrammingFundamentals)
                & EnrolledIn(X, AI) => Eligible(X, AI)
          R5: Teaches(X, ML) => Instructor(X, ML)
          R6: Enrolled(X, ML) => UsesLab(X, Lab1)
          R7: Staff(X) & HasClearance(X, Maintenance) => CanMaintain(X, Campus)
        """
        changed = True
        while changed:
            changed = False
            new_facts = set()

            for fact in list(self.facts):
                pred, args = _extract(fact)

                # R1: Teaches(X, AI) => Instructor(X, AI)
                if pred == "Teaches" and len(args) == 2 and args[1] == "AI":
                    derived = f"Instructor({args[0]}, AI)"
                    if derived not in self.facts:
                        new_facts.add(derived)

                # R2: Instructor(X, AI) => UsesLab(X, Lab1)
                if pred == "Instructor" and len(args) == 2 and args[1] == "AI":
                    derived = f"UsesLab({args[0]}, Lab1)"
                    if derived not in self.facts:
                        new_facts.add(derived)

                # R3: Enrolled(X, AI) => UsesLab(X, Lab1)
                if pred == "Enrolled" and len(args) == 2 and args[1] == "AI":
                    derived = f"UsesLab({args[0]}, Lab1)"
                    if derived not in self.facts:
                        new_facts.add(derived)

                # R5: Teaches(X, ML) => Instructor(X, ML)
                if pred == "Teaches" and len(args) == 2 and args[1] == "ML":
                    derived = f"Instructor({args[0]}, ML)"
                    if derived not in self.facts:
                        new_facts.add(derived)

                # R6: Enrolled(X, ML) => UsesLab(X, Lab1)
                if pred == "Enrolled" and len(args) == 2 and args[1] == "ML":
                    derived = f"UsesLab({args[0]}, Lab1)"
                    if derived not in self.facts:
                        new_facts.add(derived)

                # R7: Staff(X) & HasClearance(X, Maintenance) => CanMaintain(X, Campus)
                if pred == "Staff":
                    person = args[0]
                    if f"HasClearance({person}, Maintenance)" in self.facts:
                        derived = f"CanMaintain({person}, Campus)"
                        if derived not in self.facts:
                            new_facts.add(derived)

            # R4: Student(X) & Completed(X, ProgrammingFundamentals) & EnrolledIn(X, AI)
            for fact in list(self.facts):
                pred, args = _extract(fact)
                if pred == "Student":
                    person = args[0]
                    if (f"Completed({person}, ProgrammingFundamentals)" in self.facts
                            and f"EnrolledIn({person}, AI)" in self.facts):
                        derived = f"Eligible({person}, AI)"
                        if derived not in self.facts:
                            new_facts.add(derived)

            if new_facts:
                self.facts |= new_facts
                changed = True

    def query(self, fact: str) -> bool:
        """Check if a fact is entailed by the knowledge base."""
        return fact in self.facts

    def add_fact(self, fact: str):
        """Add a new fact and re-run forward chaining."""
        self.facts.add(fact)
        self._run_forward_chain()

    def explain(self, fact: str) -> list:
        """
        Return a simple explanation chain for how a fact is entailed.
        """
        pred, args = _extract(fact)
        chain = []

        if fact in INITIAL_FACTS:
            chain.append(f"[Given] {fact}")
            return chain

        if not self.query(fact):
            return [f"[Not Entailed] {fact} is not in the knowledge base."]

        # Build explanation based on known rules
        if pred == "Instructor" and len(args) == 2:
            person, subject = args
            teaches_fact = f"Teaches({person}, {subject})"
            if teaches_fact in self.facts:
                chain.append(f"[Given] {teaches_fact}")
                chain.append(f"[Rule R1] Teaches(X, {subject}) => Instructor(X, {subject})")
                chain.append(f"[Derived] {fact}")

        elif pred == "UsesLab" and len(args) == 2:
            person, lab = args
            for subj in ["AI", "ML"]:
                instr = f"Instructor({person}, {subj})"
                if instr in self.facts:
                    chain += self.explain(instr)
                    chain.append(f"[Rule R2] Instructor(X, {subj}) => UsesLab(X, {lab})")
                    chain.append(f"[Derived] {fact}")
                    return chain
            for subj in ["AI", "ML"]:
                enr = f"Enrolled({person}, {subj})"
                if enr in self.facts:
                    chain.append(f"[Given] {enr}")
                    chain.append(f"[Rule R3/R6] Enrolled(X, {subj}) => UsesLab(X, {lab})")
                    chain.append(f"[Derived] {fact}")
                    return chain

        elif pred == "Eligible" and len(args) == 2:
            person, subject = args
            chain.append(f"[Given] Student({person})")
            chain.append(f"[Given] Completed({person}, ProgrammingFundamentals)")
            chain.append(f"[Given] EnrolledIn({person}, {subject})")
            chain.append("[Rule R4] Student(X) & Completed(X, ProgrammingFundamentals)"
                         f" & EnrolledIn(X, {subject}) => Eligible(X, {subject})")
            chain.append(f"[Derived] {fact}")

        elif pred == "CanMaintain":
            person, target = args
            chain.append(f"[Given] Staff({person})")
            chain.append(f"[Given] HasClearance({person}, Maintenance)")
            chain.append("[Rule R7] Staff(X) & HasClearance(X, Maintenance) => CanMaintain(X, Campus)")
            chain.append(f"[Derived] {fact}")

        else:
            chain.append(f"[Entailed] {fact}")

        return chain


# ────────────────────────────────────────────────────────────────────────────
#  Role-based permission checks
# ────────────────────────────────────────────────────────────────────────────

ROLE_PERMISSIONS = {
    "student":    {"AI_Lab_Support", "Viva_Scheduling", "Access_Request"},
    "instructor": {"AI_Lab_Support", "Viva_Scheduling", "Access_Request", "Maintenance"},
    "staff":      {"AI_Lab_Support", "Access_Request", "Maintenance", "Emergency_Help"},
}


def check_role_permission(role: str, category: str) -> tuple:
    """
    Check if the given role has permission to request the given category.

    Returns:
        (allowed: bool, reason: str)
    """
    allowed_cats = ROLE_PERMISSIONS.get(role, set())
    if category in allowed_cats:
        return True, f"Role '{role}' is authorized for category '{category}'."
    return False, (
        f"Role '{role}' is NOT authorized for category '{category}'. "
        f"Allowed categories: {', '.join(sorted(allowed_cats))}."
    )


# ────────────────────────────────────────────────────────────────────────────
#  Main public API
# ────────────────────────────────────────────────────────────────────────────

_kb = KnowledgeBase()


def run_logic_check(request: dict) -> dict:
    """
    Main entry point for the Logic / Knowledge Base module.

    Behavior varies by request_type:
    - Eligibility_Check: evaluates the FOL query directly
    - All others: checks role authorization + student eligibility if student

    Parameters:
        request (dict): Standardized request object.

    Returns:
        dict: {
            'allowed'    : bool,
            'entailed'   : bool,
            'explanation': list of str,
            'reason'     : str
        }
    """
    role         = request.get("role", "student")
    category     = request.get("category", "")
    name         = request.get("name", "Unknown")
    request_type = request.get("request_type", "")
    query        = request.get("query", "")

    result = {
        "allowed":     False,
        "entailed":    False,
        "explanation": [],
        "reason":      ""
    }

    # ── Eligibility_Check branch ─────────────────────────────────────────────
    if request_type == "Eligibility_Check":
        if not query:
            result["reason"]      = "No query provided for eligibility check."
            result["explanation"] = ["[Error] Empty query."]
            return result

        # Attempt to match query to known persons dynamically
        # Inject user as student if name found
        capitalized = name.strip().capitalize() if name else "Unknown"
        student_fact = f"Student({capitalized})"
        if student_fact not in _kb.facts:
            _kb.add_fact(student_fact)

        entailed = _kb.query(query)
        result["entailed"]    = entailed
        result["allowed"]     = True  # query type always allowed to run
        result["explanation"] = _kb.explain(query)
        result["reason"]      = (
            f"Query '{query}' IS entailed by the knowledge base."
            if entailed else
            f"Query '{query}' is NOT entailed by the knowledge base."
        )
        return result

    # ── All other request types ──────────────────────────────────────────────
    # Step 1: role-based permission
    perm_ok, perm_reason = check_role_permission(role, category)
    if not perm_ok:
        result["reason"]      = perm_reason
        result["explanation"] = [f"[Rejected] {perm_reason}"]
        return result

    # Step 2: if student, check AI eligibility for AI_Lab_Support
    explanation = [f"[OK] {perm_reason}"]
    if role == "student" and category == "AI_Lab_Support":
        # Normalize name to capitalize
        person = name.strip().capitalize()
        # Add student fact if missing
        if f"Student({person})" not in _kb.facts:
            _kb.add_fact(f"Student({person})")
        # Check enrollment
        enrolled_fact = f"Enrolled({person}, AI)"
        if enrolled_fact not in _kb.facts:
            _kb.add_fact(enrolled_fact)  # grant enrollment based on request
        uses_lab_fact = f"UsesLab({person}, Lab1)"
        if _kb.query(uses_lab_fact):
            explanation += _kb.explain(uses_lab_fact)
            explanation.append(f"[OK] {person} has lab access rights.")
        else:
            explanation.append(f"[Note] {person} not found in lab access list; access granted by role.")

    elif role == "student" and category == "Viva_Scheduling":
        person = name.strip().capitalize()
        explanation.append(f"[OK] {person} is eligible for viva scheduling as a student.")

    elif role == "instructor":
        person = name.strip().capitalize()
        if f"Teaches({person}, AI)" not in _kb.facts:
            _kb.add_fact(f"Teaches({person}, AI)")
        explanation.append(f"[OK] Instructor {person} has access rights.")

    elif role == "staff":
        person = name.strip().capitalize()
        explanation.append(f"[OK] Staff member {person} is authorized.")

    result["allowed"]     = True
    result["entailed"]    = True
    result["explanation"] = explanation
    result["reason"]      = f"Request is valid. Role '{role}' is authorized for '{category}'."
    return result


def display_logic_output(logic_output: dict) -> None:
    """Print logic/KB results in human-readable format."""
    print("\n" + "-" * 50)
    print("  LOGIC / KNOWLEDGE BASE RESULT")
    print("-" * 50)
    status = "ALLOWED ✓" if logic_output["allowed"] else "REJECTED ✗"
    print(f"  Status      : {status}")
    print(f"  Reason      : {logic_output['reason']}")
    print("  Explanation Chain:")
    for step in logic_output["explanation"]:
        print(f"    {step}")
    print("-" * 50)

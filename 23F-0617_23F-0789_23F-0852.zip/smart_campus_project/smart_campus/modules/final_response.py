"""
============================================================
Module: final_response.py
Author: Smart Campus AI System
Description:
    Final Response Layer for the Smart Campus AI Decision
    Support and Automation System.

    Responsibilities:
    - Collect outputs from all executed modules
    - Combine them into a single coherent response object
    - Display a formatted, user-friendly summary
    - Handle both successful and rejected scenarios
============================================================
"""

import json


def build_final_response(request: dict,
                         ann_output: dict  = None,
                         logic_output: dict = None,
                         csp_output: dict  = None,
                         search_output: dict = None) -> dict:
    """
    Aggregate outputs from executed modules into a final response.

    Parameters:
        request       (dict): Original standardized request.
        ann_output    (dict): Output from ANN module, or None.
        logic_output  (dict): Output from Logic/KB module, or None.
        csp_output    (dict): Output from CSP module, or None.
        search_output (dict): Output from Search module, or None.

    Returns:
        dict: Final response object following standard template.
    """
    request_id   = request.get("request_id", "REQ???")
    request_type = request.get("request_type", "")

    response = {
        "request_id":  request_id,
        "decision":    "pending",
        "priority":    {},
        "eligibility": {},
        "assignment":  {},
        "route":       {},
        "message":     ""
    }

    # ── Determine overall decision ───────────────────────────────────────────
    if logic_output and not logic_output.get("allowed", True):
        response["decision"]    = "rejected"
        response["eligibility"] = {
            "allowed":     False,
            "explanation": " | ".join(logic_output.get("explanation", []))
        }
        response["message"] = (
            "Your request has been rejected. "
            + logic_output.get("reason", "Reason unknown.")
        )
        return response

    if csp_output and csp_output.get("decision") == "rejected":
        response["decision"]   = "rejected"
        response["assignment"] = {
            "decision": "rejected",
            "notes":    csp_output.get("notes", "No slots available.")
        }
        if logic_output:
            response["eligibility"] = {
                "allowed":     logic_output.get("allowed", False),
                "explanation": " | ".join(logic_output.get("explanation", []))
            }
        response["message"] = (
            "Your request was logically valid but could not be scheduled. "
            + csp_output.get("notes", "")
        )
        return response

    if search_output and not search_output.get("path"):
        response["decision"] = "rejected"
        response["message"]  = (
            "No route could be found between the specified locations. "
            + search_output.get("error", "")
        )
        return response

    # ── Build successful response fields ─────────────────────────────────────
    response["decision"] = "accepted" if (
        request_type != "Eligibility_Check"
        and request_type != "Navigation_Only"
    ) else "completed" if request_type == "Navigation_Only" else "answered"

    # ANN priority
    if ann_output:
        response["priority"] = {
            "binary_priority": ann_output.get("binary_priority", ""),
            "final_priority":  ann_output.get("final_priority", ""),
            "confidence":      ann_output.get("confidence", 0.0),
        }

    # Logic / eligibility
    if logic_output:
        if request_type == "Eligibility_Check":
            response["eligibility"] = {
                "entailed":    logic_output.get("entailed", False),
                "explanation": " | ".join(logic_output.get("explanation", []))
            }
        else:
            response["eligibility"] = {
                "allowed":     logic_output.get("allowed", False),
                "explanation": " | ".join(logic_output.get("explanation", []))
            }

    # CSP assignment
    if csp_output and csp_output.get("decision") == "accepted":
        response["assignment"] = {
            "room": csp_output.get("assigned_room", ""),
            "slot": csp_output.get("assigned_slot", None),
        }
        if csp_output.get("full_schedule"):
            response["assignment"]["full_schedule"] = csp_output["full_schedule"]

    # Search route
    if search_output and search_output.get("path"):
        response["route"] = {
            "algorithm": search_output.get("algorithm_used", ""),
            "path":      search_output.get("path", []),
            "cost":      search_output.get("cost", 0),
            "steps":     search_output.get("steps", 0),
        }

    # ── Build human message ──────────────────────────────────────────────────
    name = request.get("name", "User")
    msg_parts = []

    if request_type == "Navigation_Only":
        if response["route"]:
            path_str = " → ".join(response["route"]["path"])
            msg_parts.append(
                f"Best route from {request.get('current_location')} "
                f"to {request.get('destination')} found using "
                f"{response['route']['algorithm']}: {path_str} "
                f"(Cost: {response['route']['cost']}, Steps: {response['route']['steps']})."
            )
        response["decision"] = "completed"

    elif request_type == "Eligibility_Check":
        entailed = response["eligibility"].get("entailed", False)
        query    = request.get("query", "")
        msg_parts.append(
            f"Query '{query}' is {'ENTAILED' if entailed else 'NOT ENTAILED'} "
            "by the knowledge base."
        )
        response["decision"] = "answered"

    elif request_type in ("Booking_or_Scheduling", "Urgent_Service_Request",
                          "Full_Service_Request"):
        if response["assignment"]:
            room = response["assignment"].get("room", "")
            slot = response["assignment"].get("slot", "")
            msg_parts.append(
                f"Your request has been accepted, {name}. "
                f"You are assigned to {room} in Slot {slot}."
            )
        if response["route"]:
            path_str = " → ".join(response["route"]["path"])
            msg_parts.append(
                f"Recommended route: {path_str} "
                f"(Cost: {response['route']['cost']})."
            )
        if response["priority"]:
            msg_parts.append(
                f"Priority level: {response['priority']['final_priority'].upper()} "
                f"(confidence: {response['priority']['confidence']:.0%})."
            )
        response["decision"] = "accepted"

    response["message"] = " ".join(msg_parts) if msg_parts else "Request processed."
    return response


def display_final_response(final_response: dict) -> None:
    """
    Print the final response in a polished, user-friendly format.
    """
    print("\n")
    print("╔" + "═" * 58 + "╗")
    print("║        SMART CAMPUS AI — FINAL RESPONSE                 ║")
    print("╠" + "═" * 58 + "╣")

    def row(label: str, value: str):
        # Word-wrap value to fit within 38 chars
        words = value.split()
        lines = []
        current = ""
        for w in words:
            if len(current) + len(w) + 1 <= 38:
                current = (current + " " + w).strip()
            else:
                if current:
                    lines.append(current)
                current = w
        if current:
            lines.append(current)
        first = True
        for line in lines:
            lbl = label if first else ""
            print(f"║  {lbl:<18}: {line:<38}║")
            first = False

    decision     = final_response.get("decision", "").upper()
    decision_sym = "✓ ACCEPTED" if decision in ("ACCEPTED", "COMPLETED", "ANSWERED") else "✗ REJECTED"

    row("Request ID", final_response.get("request_id", ""))
    row("Decision",   decision_sym)

    # Priority
    if final_response.get("priority"):
        p = final_response["priority"]
        row("Binary Priority", p.get("binary_priority", "").upper())
        row("Final Priority",  p.get("final_priority", "").upper())
        row("Confidence",      f"{p.get('confidence', 0):.2%}")

    # Eligibility
    if final_response.get("eligibility"):
        e = final_response["eligibility"]
        if "allowed" in e:
            row("Eligibility", "ALLOWED ✓" if e["allowed"] else "DENIED ✗")
        elif "entailed" in e:
            row("Entailed", "YES ✓" if e["entailed"] else "NO ✗")

    # Assignment
    if final_response.get("assignment"):
        a = final_response["assignment"]
        if a.get("room"):
            row("Assigned Room", a.get("room", ""))
            row("Assigned Slot", str(a.get("slot", "")))

    # Route
    if final_response.get("route"):
        r = final_response["route"]
        if r.get("path"):
            row("Algorithm",  r.get("algorithm", ""))
            row("Route",      " → ".join(r.get("path", [])))
            row("Route Cost", str(r.get("cost", 0)))
            row("Steps",      str(r.get("steps", 0)))

    print("╠" + "═" * 58 + "╣")
    # Message – wrap at 55
    msg = final_response.get("message", "")
    words = msg.split()
    lines = []
    cur = ""
    for w in words:
        if len(cur) + len(w) + 1 <= 54:
            cur = (cur + " " + w).strip()
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    for line in lines:
        print(f"║  {line:<56}║")
    print("╚" + "═" * 58 + "╝\n")


def export_response_json(final_response: dict, filepath: str = None) -> str:
    """
    Serialize the final response to a JSON string.
    Optionally write to a file.

    Parameters:
        final_response (dict): The final response dictionary.
        filepath (str):        Optional path to write JSON file.

    Returns:
        str: JSON string.
    """
    json_str = json.dumps(final_response, indent=2)
    if filepath:
        try:
            with open(filepath, "w") as f:
                f.write(json_str)
            print(f"[✓] Response saved to {filepath}")
        except OSError as e:
            print(f"[!] Could not save response: {e}")
    return json_str

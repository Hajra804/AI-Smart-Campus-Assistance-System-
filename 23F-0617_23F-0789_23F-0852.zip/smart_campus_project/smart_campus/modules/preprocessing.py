"""
============================================================
Module: preprocessing.py
Author: Smart Campus AI System
Description:
    Input and Preprocessing Module for the Smart Campus AI
    Decision Support and Automation System.
    
    Responsibilities:
    - Collect structured CLI input from the user field by field
    - Validate required fields and value ranges
    - Normalize location names, roles, and request types
    - Build a standardized request object (dictionary)
    - Prepare module-specific data (ANN feature flags, search nodes, etc.)
    - Return a clean request ready for the Request Router
============================================================
"""

import uuid

# ── Valid campus nodes ──────────────────────────────────────────────────────
VALID_LOCATIONS = [
    "Main_Gate", "Parking", "Admin_Block", "Student_Services",
    "Exam_Hall", "Seminar_Room", "Library", "AI_Lab",
    "Science_Block", "Cafeteria", "Hostel", "Medical_Center",
    "Bus_Stop"
]

# ── Allowed field values ────────────────────────────────────────────────────
VALID_ROLES = ["student", "instructor", "staff"]

VALID_REQUEST_TYPES = [
    "Navigation_Only",
    "Eligibility_Check",
    "Booking_or_Scheduling",
    "Urgent_Service_Request",
    "Full_Service_Request"
]

VALID_CATEGORIES = [
    "AI_Lab_Support",
    "Viva_Scheduling",
    "Access_Request",
    "Maintenance",
    "Emergency_Help"
]

# ── Normalization maps ──────────────────────────────────────────────────────
LOCATION_ALIASES = {
    "main gate": "Main_Gate",
    "maingate": "Main_Gate",
    "parking": "Parking",
    "admin block": "Admin_Block",
    "adminblock": "Admin_Block",
    "admin": "Admin_Block",
    "student services": "Student_Services",
    "studentservices": "Student_Services",
    "exam hall": "Exam_Hall",
    "examhall": "Exam_Hall",
    "seminar room": "Seminar_Room",
    "seminarroom": "Seminar_Room",
    "library": "Library",
    "ai lab": "AI_Lab",
    "ailab": "AI_Lab",
    "ai_lab": "AI_Lab",
    "science block": "Science_Block",
    "scienceblock": "Science_Block",
    "cafeteria": "Cafeteria",
    "hostel": "Hostel",
    "medical center": "Medical_Center",
    "medicalcenter": "Medical_Center",
    "medical": "Medical_Center",
    "bus stop": "Bus_Stop",
    "busstop": "Bus_Stop",
}

REQUEST_TYPE_ALIASES = {
    "1": "Navigation_Only",
    "navigation_only": "Navigation_Only",
    "navigation only": "Navigation_Only",
    "2": "Eligibility_Check",
    "eligibility_check": "Eligibility_Check",
    "eligibility check": "Eligibility_Check",
    "3": "Booking_or_Scheduling",
    "booking_or_scheduling": "Booking_or_Scheduling",
    "booking or scheduling": "Booking_or_Scheduling",
    "booking": "Booking_or_Scheduling",
    "scheduling": "Booking_or_Scheduling",
    "4": "Urgent_Service_Request",
    "urgent_service_request": "Urgent_Service_Request",
    "urgent service request": "Urgent_Service_Request",
    "urgent": "Urgent_Service_Request",
    "5": "Full_Service_Request",
    "full_service_request": "Full_Service_Request",
    "full service request": "Full_Service_Request",
    "full": "Full_Service_Request",
}

CATEGORY_ALIASES = {
    "1": "AI_Lab_Support",
    "ai_lab_support": "AI_Lab_Support",
    "ai lab support": "AI_Lab_Support",
    "ai lab": "AI_Lab_Support",
    "2": "Viva_Scheduling",
    "viva_scheduling": "Viva_Scheduling",
    "viva scheduling": "Viva_Scheduling",
    "viva": "Viva_Scheduling",
    "3": "Access_Request",
    "access_request": "Access_Request",
    "access request": "Access_Request",
    "access": "Access_Request",
    "4": "Maintenance",
    "maintenance": "Maintenance",
    "5": "Emergency_Help",
    "emergency_help": "Emergency_Help",
    "emergency help": "Emergency_Help",
    "emergency": "Emergency_Help",
}


def normalize_location(raw: str) -> str:
    """
    Normalize a raw location string to the standard campus node name.
    Returns None if no match is found.
    """
    key = raw.strip().lower()
    if key in LOCATION_ALIASES:
        return LOCATION_ALIASES[key]
    # Try direct match (case-insensitive) against valid list
    for loc in VALID_LOCATIONS:
        if loc.lower() == key:
            return loc
    return None


def normalize_role(raw: str) -> str:
    """
    Normalize role string to lowercase standard form.
    Returns None if invalid.
    """
    role = raw.strip().lower()
    if role in VALID_ROLES:
        return role
    return None


def normalize_request_type(raw: str) -> str:
    """
    Normalize request type string using alias map.
    Returns None if invalid.
    """
    key = raw.strip().lower()
    return REQUEST_TYPE_ALIASES.get(key, None)


def normalize_category(raw: str) -> str:
    """
    Normalize category string using alias map.
    Returns None if invalid.
    """
    key = raw.strip().lower()
    return CATEGORY_ALIASES.get(key, None)


def get_int_in_range(prompt: str, lo: int, hi: int) -> int:
    """
    Prompt user for an integer within [lo, hi]. Keeps asking until valid input.
    """
    while True:
        try:
            value = int(input(prompt).strip())
            if lo <= value <= hi:
                return value
            print(f"  [!] Please enter a number between {lo} and {hi}.")
        except ValueError:
            print("  [!] Invalid input. Please enter a whole number.")


def collect_input() -> dict:
    """
    Collect structured CLI input from the user, field by field.
    Validates and normalizes each field before building the request object.
    Returns a standardized request dictionary ready for the Router.
    """
    print("\n" + "=" * 60)
    print("   SMART CAMPUS AI DECISION SUPPORT SYSTEM")
    print("=" * 60)
    print("Please fill in the following fields to submit your request.\n")

    # ── Name ────────────────────────────────────────────────────────────────
    while True:
        name = input("Enter Name: ").strip()
        if name:
            break
        print("  [!] Name cannot be empty.")

    # ── Role ────────────────────────────────────────────────────────────────
    while True:
        raw_role = input("Enter Role (student / instructor / staff): ")
        role = normalize_role(raw_role)
        if role:
            break
        print("  [!] Invalid role. Choose from: student, instructor, staff.")

    # ── Request Type ────────────────────────────────────────────────────────
    print("\nRequest Types:")
    print("  1. Navigation_Only")
    print("  2. Eligibility_Check")
    print("  3. Booking_or_Scheduling")
    print("  4. Urgent_Service_Request")
    print("  5. Full_Service_Request")
    while True:
        raw_rt = input("Enter choice (number or name): ")
        request_type = normalize_request_type(raw_rt)
        if request_type:
            break
        print("  [!] Invalid request type. Enter a number 1-5 or the type name.")

    # ── Conditional fields ──────────────────────────────────────────────────
    category        = ""
    current_location = ""
    destination     = ""
    preferred_slot  = None
    severity        = 0
    time_sensitivity = 0
    crowd_level     = 0
    group_id        = ""
    query           = ""
    description_note = ""

    if request_type == "Navigation_Only":
        while True:
            raw = input("Enter Current Location: ")
            loc = normalize_location(raw)
            if loc:
                current_location = loc
                break
            print(f"  [!] Unknown location. Valid: {', '.join(VALID_LOCATIONS)}")

        while True:
            raw = input("Enter Destination: ")
            loc = normalize_location(raw)
            if loc:
                destination = loc
                break
            print(f"  [!] Unknown location. Valid: {', '.join(VALID_LOCATIONS)}")

        if current_location == destination:
            print("  [!] Warning: source and destination are the same.")

    elif request_type == "Eligibility_Check":
        print("\nExamples of queries:")
        print("  UsesLab(DrKhan, Lab1)")
        print("  Eligible(Ali, AI)")
        print("  Teaches(DrKhan, AI)")
        query = input("Enter Eligibility Query: ").strip()
        if not query:
            query = "Eligible(Unknown, Unknown)"

    elif request_type == "Booking_or_Scheduling":
        print("\nCategories:")
        print("  1. AI_Lab_Support  2. Viva_Scheduling  3. Access_Request")
        print("  4. Maintenance     5. Emergency_Help")
        while True:
            raw = input("Enter Category (number or name): ")
            cat = normalize_category(raw)
            if cat:
                category = cat
                break
            print("  [!] Invalid category.")

        preferred_slot = get_int_in_range("Enter Preferred Slot (1-4): ", 1, 4)

        while True:
            raw = input("Enter Current Location (optional, press Enter to skip): ").strip()
            if not raw:
                break
            loc = normalize_location(raw)
            if loc:
                current_location = loc
                break
            print(f"  [!] Unknown location.")

        group_id = input("Enter Group ID (optional, press Enter to skip): ").strip()

    elif request_type == "Urgent_Service_Request":
        print("\nCategories:")
        print("  1. AI_Lab_Support  2. Viva_Scheduling  3. Access_Request")
        print("  4. Maintenance     5. Emergency_Help")
        while True:
            raw = input("Enter Category (number or name): ")
            cat = normalize_category(raw)
            if cat:
                category = cat
                break
            print("  [!] Invalid category.")

        while True:
            raw = input("Enter Current Location: ")
            loc = normalize_location(raw)
            if loc:
                current_location = loc
                break
            print(f"  [!] Unknown location.")

        severity         = get_int_in_range("Enter Severity (1-10): ", 1, 10)
        time_sensitivity = get_int_in_range("Enter Time Sensitivity (1-10): ", 1, 10)
        crowd_level      = get_int_in_range("Enter Crowd Level (1-10): ", 1, 10)
        preferred_slot   = get_int_in_range("Enter Preferred Slot (1-4): ", 1, 4)

    elif request_type == "Full_Service_Request":
        print("\nCategories:")
        print("  1. AI_Lab_Support  2. Viva_Scheduling  3. Access_Request")
        print("  4. Maintenance     5. Emergency_Help")
        while True:
            raw = input("Enter Category (number or name): ")
            cat = normalize_category(raw)
            if cat:
                category = cat
                break
            print("  [!] Invalid category.")

        while True:
            raw = input("Enter Current Location: ")
            loc = normalize_location(raw)
            if loc:
                current_location = loc
                break
            print(f"  [!] Unknown location.")

        preferred_slot   = get_int_in_range("Enter Preferred Slot (1-4): ", 1, 4)
        severity         = get_int_in_range("Enter Severity (1-10): ", 1, 10)
        time_sensitivity = get_int_in_range("Enter Time Sensitivity (1-10): ", 1, 10)
        crowd_level      = get_int_in_range("Enter Crowd Level (1-10): ", 1, 10)
        description_note = input("Enter Description Note (optional): ").strip()

    # ── Build standardized request object ───────────────────────────────────
    request_id = "REQ" + str(uuid.uuid4())[:6].upper()

    request_obj = {
        "request_id":       request_id,
        "name":             name,
        "role":             role,
        "request_type":     request_type,
        "category":         category,
        "current_location": current_location,
        "destination":      destination,
        "preferred_slot":   preferred_slot,
        "severity":         severity,
        "time_sensitivity": time_sensitivity,
        "crowd_level":      crowd_level,
        "group_id":         group_id,
        "query":            query,
        "eligibility_claim": True,
        "description_note": description_note,
    }

    # ── Prepare module flags ─────────────────────────────────────────────────
    needs_ann    = request_type in ("Urgent_Service_Request", "Full_Service_Request")
    needs_logic  = request_type in ("Eligibility_Check", "Booking_or_Scheduling",
                                     "Urgent_Service_Request", "Full_Service_Request")
    needs_csp    = request_type in ("Booking_or_Scheduling", "Urgent_Service_Request",
                                     "Full_Service_Request")
    needs_search = request_type in ("Navigation_Only", "Full_Service_Request")

    request_obj["needs_ann"]    = needs_ann
    request_obj["needs_logic"]  = needs_logic
    request_obj["needs_csp"]    = needs_csp
    request_obj["needs_search"] = needs_search

    print("\n[✓] Request validated and standardized successfully.")
    return request_obj

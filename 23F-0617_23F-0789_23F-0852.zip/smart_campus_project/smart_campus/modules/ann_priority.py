"""
============================================================
Module: ann_priority.py
Author: Smart Campus AI System
Description:
    ANN Priority Prediction Module for the Smart Campus AI
    Decision Support and Automation System.

    Contains:
    1. Perceptron  – Binary classifier (urgent vs not_urgent)
    2. MLP         – Multiclass priority classifier
                     (low / normal / high / urgent)

    Both models use pre-set weights (no external library needed).
    Feature order: Role, RequestType, Severity, TimeSensitivity,
                   CrowdLevel, Distance, Eligibility

    ANN predicts PRIORITY ONLY.
    It does NOT grant or deny permissions.
============================================================
"""

import math

# ── Encoding maps ────────────────────────────────────────────────────────────
ROLE_ENCODING = {
    "student":    0,
    "instructor": 1,
    "staff":      2
}

REQUEST_TYPE_ENCODING = {
    "AI_Lab_Support":  0,
    "Viva_Scheduling": 1,
    "Access_Request":  2,
    "Maintenance":     3,
    "Emergency_Help":  4
}

FEATURE_ORDER = [
    "Role", "RequestType", "Severity",
    "TimeSensitivity", "CrowdLevel", "Distance", "Eligibility"
]

# Campus distance table from common starting locations to AI_Lab (approx hops)
CAMPUS_DISTANCES = {
    "Hostel": 4, "Cafeteria": 3, "Science_Block": 2, "AI_Lab": 0,
    "Library": 2, "Seminar_Room": 3, "Exam_Hall": 4, "Student_Services": 4,
    "Admin_Block": 4, "Main_Gate": 4, "Parking": 4, "Medical_Center": 5,
    "Bus_Stop": 6
}


def build_feature_vector(request: dict) -> list:
    """
    Convert a standardized request dictionary into a numeric feature vector.
    Feature order: [Role, RequestType, Severity, TimeSensitivity,
                    CrowdLevel, Distance, Eligibility]

    Parameters:
        request (dict): Standardized request object.

    Returns:
        list: Numeric feature vector of length 7.
    """
    role_enc    = ROLE_ENCODING.get(request.get("role", "student"), 0)
    rt_enc      = REQUEST_TYPE_ENCODING.get(request.get("category", "AI_Lab_Support"), 0)
    severity    = float(request.get("severity", 5))
    time_sens   = float(request.get("time_sensitivity", 5))
    crowd       = float(request.get("crowd_level", 5))
    distance    = float(CAMPUS_DISTANCES.get(request.get("current_location", "Hostel"), 4))
    eligibility = 1.0 if request.get("eligibility_claim", True) else 0.0

    return [role_enc, rt_enc, severity, time_sens, crowd, distance, eligibility]


# ────────────────────────────────────────────────────────────────────────────
#  PERCEPTRON – Binary Classifier
# ────────────────────────────────────────────────────────────────────────────

class Perceptron:
    """
    Binary Perceptron classifier.
    Input: 7-dimensional feature vector
    Output: 0 (not_urgent) or 1 (urgent)

    Weights are tuned so that high severity + high time-sensitivity
    consistently maps to urgent (1).
    """

    def __init__(self):
        # Weights: [Role, RequestType, Severity, TimeSensitivity, CrowdLevel, Distance, Eligibility]
        self.weights = [0.05, 0.10, 0.30, 0.35, 0.10, -0.05, 0.05]
        self.bias    = -3.5

    def _weighted_sum(self, features: list) -> float:
        """Compute weighted sum of inputs plus bias."""
        total = self.bias
        for w, x in zip(self.weights, features):
            total += w * x
        return total

    def _activation(self, z: float) -> int:
        """Step activation function: returns 1 if z >= 0, else 0."""
        return 1 if z >= 0 else 0

    def predict(self, features: list) -> dict:
        """
        Predict binary urgency from feature vector.

        Parameters:
            features (list): Numeric feature vector.

        Returns:
            dict: {'label': 'urgent'/'not_urgent', 'raw': int}
        """
        z      = self._weighted_sum(features)
        output = self._activation(z)
        label  = "urgent" if output == 1 else "not_urgent"
        return {"label": label, "raw": output, "weighted_sum": round(z, 4)}


# ────────────────────────────────────────────────────────────────────────────
#  MLP – Multiclass Priority Classifier (2 hidden layers)
# ────────────────────────────────────────────────────────────────────────────

def _relu(x: float) -> float:
    """ReLU activation function."""
    return max(0.0, x)


def _softmax(vec: list) -> list:
    """Softmax activation for output layer."""
    max_v = max(vec)
    exps  = [math.exp(v - max_v) for v in vec]
    total = sum(exps)
    return [e / total for e in exps]


def _dot(weights: list, inputs: list, bias: float) -> float:
    """Compute dot product plus bias."""
    return sum(w * x for w, x in zip(weights, inputs)) + bias


class MLP:
    """
    Multi-Layer Perceptron with 2 hidden layers.
    Architecture:
        Input  (7)  →  Hidden1 (4)  →  Hidden2 (3)  →  Output (4)
    Output classes: [low, normal, high, urgent]
    Weights are hand-tuned for sensible behavior.
    """

    CLASSES = ["low", "normal", "high", "urgent"]

    def __init__(self):
        # ── Hidden Layer 1 weights: 4 neurons × 7 inputs ────────────────────
        # Each inner list = weights for one neuron
        self.h1_weights = [
            [ 0.10,  0.15,  0.40,  0.35,  0.20, -0.10,  0.10],  # h1_1
            [ 0.05,  0.10,  0.25,  0.45,  0.15, -0.05,  0.05],  # h1_2
            [ 0.15,  0.20,  0.30,  0.20,  0.30, -0.15,  0.10],  # h1_3
            [ 0.20,  0.10,  0.15,  0.15,  0.40, -0.20,  0.05],  # h1_4
        ]
        self.h1_bias = [-2.0, -2.5, -2.0, -2.0]

        # ── Hidden Layer 2 weights: 3 neurons × 4 inputs ────────────────────
        self.h2_weights = [
            [0.50,  0.40,  0.20,  0.30],  # h2_1
            [0.30,  0.50,  0.40,  0.20],  # h2_2
            [0.20,  0.30,  0.50,  0.40],  # h2_3
        ]
        self.h2_bias = [-0.5, -0.5, -0.5]

        # ── Output layer weights: 4 outputs × 3 hidden2 inputs ──────────────
        self.out_weights = [
            [-0.80, -0.60, -0.40],  # low
            [-0.20,  0.30, -0.10],  # normal
            [ 0.40,  0.60,  0.30],  # high
            [ 0.80,  0.50,  0.70],  # urgent
        ]
        self.out_bias = [-1.5, -0.5, 0.0, 0.5]

    def _forward_layer(self, weights, biases, inputs, activation):
        """Generic forward pass through one layer."""
        outputs = []
        for w_row, b in zip(weights, biases):
            z = _dot(w_row, inputs, b)
            outputs.append(activation(z))
        return outputs

    def predict(self, features: list) -> dict:
        """
        Predict multiclass priority from feature vector.

        Parameters:
            features (list): 7-dimensional numeric feature vector.

        Returns:
            dict with 'label' (str), 'probabilities' (list), 'confidence' (float)
        """
        # Forward pass – hidden layer 1 (ReLU)
        h1_out = self._forward_layer(self.h1_weights, self.h1_bias, features, _relu)

        # Forward pass – hidden layer 2 (ReLU)
        h2_out = self._forward_layer(self.h2_weights, self.h2_bias, h1_out, _relu)

        # Output layer (linear then softmax)
        raw_out = []
        for w_row, b in zip(self.out_weights, self.out_bias):
            raw_out.append(_dot(w_row, h2_out, b))

        probs     = _softmax(raw_out)
        class_idx = probs.index(max(probs))
        label     = self.CLASSES[class_idx]
        confidence = round(probs[class_idx], 4)

        return {
            "label":         label,
            "probabilities": {c: round(p, 4) for c, p in zip(self.CLASSES, probs)},
            "confidence":    confidence
        }


# ── Single public API ────────────────────────────────────────────────────────

_perceptron = Perceptron()
_mlp        = MLP()


def predict_priority(request: dict) -> dict:
    """
    Run both ANN models on the given request and return a combined priority output.

    Parameters:
        request (dict): Standardized request object.

    Returns:
        dict: {
            'binary_priority': 'urgent'/'not_urgent',
            'final_priority' : 'low'/'normal'/'high'/'urgent',
            'confidence'     : float,
            'feature_vector' : list
        }
    """
    features = build_feature_vector(request)

    perc_result = _perceptron.predict(features)
    mlp_result  = _mlp.predict(features)

    return {
        "binary_priority": perc_result["label"],
        "final_priority":  mlp_result["label"],
        "confidence":      mlp_result["confidence"],
        "feature_vector":  features,
        "mlp_probabilities": mlp_result["probabilities"]
    }


def display_ann_output(ann_output: dict) -> None:
    """Print ANN results in a human-readable format."""
    print("\n" + "-" * 50)
    print("  ANN PRIORITY PREDICTION")
    print("-" * 50)
    print(f"  Feature Vector   : {ann_output['feature_vector']}")
    print(f"  [Perceptron] Binary Priority : {ann_output['binary_priority'].upper()}")
    print(f"  [MLP]        Final Priority  : {ann_output['final_priority'].upper()}")
    print(f"  [MLP]        Confidence      : {ann_output['confidence']:.2%}")
    print("  [MLP] Class Probabilities:")
    for cls, prob in ann_output["mlp_probabilities"].items():
        bar = "█" * int(prob * 20)
        print(f"    {cls:8s} : {prob:.4f}  {bar}")
    print("-" * 50)

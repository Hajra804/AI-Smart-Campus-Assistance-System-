"""
============================================================
Module: search_navigation.py
Author: Smart Campus AI System
Description:
    Search & Navigation Module for the Smart Campus AI
    Decision Support and Automation System.

    Implements multiple search algorithms on a campus graph:
        Operational (final routing):
            - BFS        (unweighted graphs)
            - A*         (weighted, heuristic available)
            - UCS        (weighted, no heuristic fallback)
        Academic / comparison:
            - DFS
            - DLS  (Depth-Limited Search)
            - IDS  (Iterative Deepening Search)
            - Bidirectional BFS
            - Greedy Best-First Search
            - RBFS (Recursive Best-First Search)

    Policy:
        if unweighted graph → BFS
        if weighted graph & heuristic available → A*
        if weighted graph & no heuristic → UCS
============================================================
"""

import heapq
from collections import deque

# ────────────────────────────────────────────────────────────────────────────
#  CAMPUS GRAPH DEFINITIONS
# ────────────────────────────────────────────────────────────────────────────

# Unweighted adjacency list (BFS / DFS / DLS / IDS / Bidirectional BFS)
UNWEIGHTED_GRAPH = {
    "Main_Gate":       ["Parking", "Bus_Stop", "Admin_Block"],
    "Parking":         ["Main_Gate", "Admin_Block", "Medical_Center", "Hostel"],
    "Admin_Block":     ["Main_Gate", "Parking", "Student_Services"],
    "Student_Services":["Admin_Block", "Library", "Exam_Hall"],
    "Exam_Hall":       ["Student_Services", "Seminar_Room"],
    "Seminar_Room":    ["Exam_Hall", "AI_Lab"],
    "Library":         ["Student_Services", "Science_Block", "AI_Lab", "Seminar_Room"],
    "AI_Lab":          ["Library", "Science_Block", "Seminar_Room"],
    "Science_Block":   ["Library", "AI_Lab", "Cafeteria"],
    "Cafeteria":       ["Science_Block", "Hostel"],
    "Hostel":          ["Parking", "Cafeteria", "Medical_Center"],
    "Medical_Center":  ["Parking", "Hostel"],
    "Bus_Stop":        ["Main_Gate", "Medical_Center"],
}

# Weighted adjacency list {node: [(neighbor, cost), ...]}
WEIGHTED_GRAPH = {
    "Main_Gate":       [("Parking", 2), ("Bus_Stop", 1), ("Admin_Block", 4)],
    "Parking":         [("Main_Gate", 2), ("Admin_Block", 2), ("Medical_Center", 2), ("Hostel", 5)],
    "Admin_Block":     [("Main_Gate", 4), ("Parking", 2), ("Student_Services", 1)],
    "Student_Services":[("Admin_Block", 1), ("Library", 2), ("Exam_Hall", 2)],
    "Exam_Hall":       [("Student_Services", 2), ("Seminar_Room", 1)],
    "Seminar_Room":    [("Exam_Hall", 1), ("AI_Lab", 2)],
    "Library":         [("Student_Services", 2), ("Science_Block", 3), ("AI_Lab", 1), ("Seminar_Room", 3)],
    "AI_Lab":          [("Library", 1), ("Science_Block", 1), ("Seminar_Room", 2)],
    "Science_Block":   [("Library", 3), ("AI_Lab", 1), ("Cafeteria", 3)],
    "Cafeteria":       [("Science_Block", 3), ("Hostel", 3)],
    "Hostel":          [("Parking", 5), ("Cafeteria", 3), ("Medical_Center", 2)],
    "Medical_Center":  [("Parking", 2), ("Hostel", 2)],
    "Bus_Stop":        [("Main_Gate", 1), ("Medical_Center", 2)],
}

# Manhattan heuristic: Euclidean-like distances to AI_Lab
# Coordinates: (x, y)
NODE_COORDS = {
    "Main_Gate":        (0, 4),
    "Parking":          (2, 4),
    "Admin_Block":      (3, 5),
    "Student_Services": (6, 5),
    "Exam_Hall":        (8, 5),
    "Seminar_Room":     (10, 4),
    "Library":          (6, 2),
    "AI_Lab":           (9, 2),
    "Science_Block":    (7, 1),
    "Cafeteria":        (4, 1),
    "Hostel":           (2, 0),
    "Medical_Center":   (1, 1),
    "Bus_Stop":         (0, 1),
}


def heuristic(node: str, goal: str) -> float:
    """Manhattan distance heuristic between two nodes."""
    if node not in NODE_COORDS or goal not in NODE_COORDS:
        return 0.0
    x1, y1 = NODE_COORDS[node]
    x2, y2 = NODE_COORDS[goal]
    return abs(x1 - x2) + abs(y1 - y2)


# ────────────────────────────────────────────────────────────────────────────
#  BFS – Breadth-First Search (unweighted, shortest path by hops)
# ────────────────────────────────────────────────────────────────────────────

def bfs(source: str, goal: str) -> dict:
    """
    Breadth-First Search on the unweighted campus graph.
    Finds the shortest path (fewest edges).
    """
    if source == goal:
        return {"path": [source], "cost": 0, "steps": 0, "nodes_expanded": 1}

    queue    = deque([[source]])
    visited  = {source}
    expanded = 0

    while queue:
        path = queue.popleft()
        node = path[-1]
        expanded += 1

        for neighbor in UNWEIGHTED_GRAPH.get(node, []):
            if neighbor == goal:
                return {
                    "path":           path + [neighbor],
                    "cost":           len(path),
                    "steps":          len(path),
                    "nodes_expanded": expanded
                }
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(path + [neighbor])

    return {"path": [], "cost": -1, "steps": -1, "nodes_expanded": expanded}


# ────────────────────────────────────────────────────────────────────────────
#  DFS – Depth-First Search
# ────────────────────────────────────────────────────────────────────────────

def dfs(source: str, goal: str) -> dict:
    """
    Depth-First Search. Not guaranteed to find the shortest path.
    Used for academic comparison.
    """
    stack    = [(source, [source])]
    visited  = set()
    expanded = 0

    while stack:
        node, path = stack.pop()
        if node in visited:
            continue
        visited.add(node)
        expanded += 1

        if node == goal:
            return {"path": path, "cost": len(path) - 1,
                    "steps": len(path) - 1, "nodes_expanded": expanded}

        for neighbor in reversed(UNWEIGHTED_GRAPH.get(node, [])):
            if neighbor not in visited:
                stack.append((neighbor, path + [neighbor]))

    return {"path": [], "cost": -1, "steps": -1, "nodes_expanded": expanded}


# ────────────────────────────────────────────────────────────────────────────
#  DLS – Depth-Limited Search
# ────────────────────────────────────────────────────────────────────────────

def _dls_recursive(node: str, goal: str, depth: int, path: list,
                   visited: set, counter: list) -> list | None:
    """Internal recursive DLS helper."""
    counter[0] += 1
    if node == goal:
        return path
    if depth == 0:
        return None
    for neighbor in UNWEIGHTED_GRAPH.get(node, []):
        if neighbor not in visited:
            visited.add(neighbor)
            result = _dls_recursive(neighbor, goal, depth - 1,
                                    path + [neighbor], visited, counter)
            if result is not None:
                return result
            visited.discard(neighbor)
    return None


def dls(source: str, goal: str, limit: int = 6) -> dict:
    """Depth-Limited Search with given depth limit."""
    counter = [0]
    result  = _dls_recursive(source, goal, limit, [source], {source}, counter)
    if result:
        return {"path": result, "cost": len(result) - 1,
                "steps": len(result) - 1, "nodes_expanded": counter[0]}
    return {"path": [], "cost": -1, "steps": -1, "nodes_expanded": counter[0]}


# ────────────────────────────────────────────────────────────────────────────
#  IDS – Iterative Deepening Search
# ────────────────────────────────────────────────────────────────────────────

def ids(source: str, goal: str, max_depth: int = 15) -> dict:
    """
    Iterative Deepening DFS. Combines DFS space efficiency with
    BFS completeness.
    """
    total_expanded = 0
    for depth in range(max_depth + 1):
        counter = [0]
        result  = _dls_recursive(source, goal, depth, [source], {source}, counter)
        total_expanded += counter[0]
        if result:
            return {"path": result, "cost": len(result) - 1,
                    "steps": len(result) - 1, "nodes_expanded": total_expanded}
    return {"path": [], "cost": -1, "steps": -1, "nodes_expanded": total_expanded}


# ────────────────────────────────────────────────────────────────────────────
#  UCS – Uniform Cost Search (weighted, optimal without heuristic)
# ────────────────────────────────────────────────────────────────────────────

def ucs(source: str, goal: str) -> dict:
    """
    Uniform Cost Search on the weighted campus graph.
    Finds the least-cost path.
    """
    # priority queue: (cost, node, path)
    heap     = [(0, source, [source])]
    visited  = {}
    expanded = 0

    while heap:
        cost, node, path = heapq.heappop(heap)
        if node in visited and visited[node] <= cost:
            continue
        visited[node] = cost
        expanded += 1

        if node == goal:
            return {"path": path, "cost": cost,
                    "steps": len(path) - 1, "nodes_expanded": expanded}

        for neighbor, edge_cost in WEIGHTED_GRAPH.get(node, []):
            new_cost = cost + edge_cost
            if neighbor not in visited or visited[neighbor] > new_cost:
                heapq.heappush(heap, (new_cost, neighbor, path + [neighbor]))

    return {"path": [], "cost": -1, "steps": -1, "nodes_expanded": expanded}


# ────────────────────────────────────────────────────────────────────────────
#  Bidirectional BFS
# ────────────────────────────────────────────────────────────────────────────

def bidirectional_bfs(source: str, goal: str) -> dict:
    """
    Bidirectional BFS on the unweighted graph.
    Searches simultaneously from source and goal.
    """
    if source == goal:
        return {"path": [source], "cost": 0, "steps": 0, "nodes_expanded": 1}

    # Build reverse adjacency for backward search
    reverse_graph: dict = {n: [] for n in UNWEIGHTED_GRAPH}
    for node, neighbors in UNWEIGHTED_GRAPH.items():
        for nb in neighbors:
            if nb in reverse_graph:
                reverse_graph[nb].append(node)

    frontier_s = deque([[source]])
    frontier_g = deque([[goal]])
    visited_s  = {source: [source]}
    visited_g  = {goal:   [goal]}
    expanded   = 0

    while frontier_s or frontier_g:
        # Expand forward frontier
        if frontier_s:
            path = frontier_s.popleft()
            node = path[-1]
            expanded += 1
            for nb in UNWEIGHTED_GRAPH.get(node, []):
                if nb not in visited_s:
                    new_path = path + [nb]
                    visited_s[nb] = new_path
                    frontier_s.append(new_path)
                    if nb in visited_g:
                        back = list(reversed(visited_g[nb]))
                        full_path = new_path + back[1:]  # avoid duplicate meeting node
                        return {"path": full_path, "cost": len(full_path) - 1,
                                "steps": len(full_path) - 1, "nodes_expanded": expanded}

        # Expand backward frontier
        if frontier_g:
            path = frontier_g.popleft()
            node = path[-1]
            expanded += 1
            for nb in reverse_graph.get(node, []):
                if nb not in visited_g:
                    new_path = path + [nb]
                    visited_g[nb] = new_path
                    frontier_g.append(new_path)
                    if nb in visited_s:
                        fwd = visited_s[nb]
                        back = list(reversed(new_path))
                        full_path = fwd + back[1:]
                        return {"path": full_path, "cost": len(full_path) - 1,
                                "steps": len(full_path) - 1, "nodes_expanded": expanded}

    return {"path": [], "cost": -1, "steps": -1, "nodes_expanded": expanded}


# ────────────────────────────────────────────────────────────────────────────
#  Greedy Best-First Search
# ────────────────────────────────────────────────────────────────────────────

def greedy_bfs(source: str, goal: str) -> dict:
    """
    Greedy Best-First Search using Manhattan heuristic.
    Not guaranteed to find optimal path.
    """
    heap     = [(heuristic(source, goal), source, [source])]
    visited  = set()
    expanded = 0

    while heap:
        _, node, path = heapq.heappop(heap)
        if node in visited:
            continue
        visited.add(node)
        expanded += 1

        if node == goal:
            return {"path": path, "cost": len(path) - 1,
                    "steps": len(path) - 1, "nodes_expanded": expanded}

        for neighbor, _ in WEIGHTED_GRAPH.get(node, []):
            if neighbor not in visited:
                h = heuristic(neighbor, goal)
                heapq.heappush(heap, (h, neighbor, path + [neighbor]))

    return {"path": [], "cost": -1, "steps": -1, "nodes_expanded": expanded}


# ────────────────────────────────────────────────────────────────────────────
#  A* Search
# ────────────────────────────────────────────────────────────────────────────

def astar(source: str, goal: str) -> dict:
    """
    A* Search. Uses actual cost (g) + heuristic estimate (h).
    Finds the optimal path on the weighted campus graph.
    """
    heap     = [(heuristic(source, goal), 0, source, [source])]
    visited  = {}
    expanded = 0

    while heap:
        f, g, node, path = heapq.heappop(heap)
        if node in visited and visited[node] <= g:
            continue
        visited[node] = g
        expanded += 1

        if node == goal:
            return {"path": path, "cost": g,
                    "steps": len(path) - 1, "nodes_expanded": expanded}

        for neighbor, edge_cost in WEIGHTED_GRAPH.get(node, []):
            new_g = g + edge_cost
            if neighbor not in visited or visited[neighbor] > new_g:
                h = heuristic(neighbor, goal)
                heapq.heappush(heap, (new_g + h, new_g, neighbor, path + [neighbor]))

    return {"path": [], "cost": -1, "steps": -1, "nodes_expanded": expanded}


# ────────────────────────────────────────────────────────────────────────────
#  RBFS – Recursive Best-First Search
# ────────────────────────────────────────────────────────────────────────────

_RBFS_INF = float("inf")


def _rbfs_inner(node: str, goal: str, g: float, f_limit: float,
                path: list, counter: list):
    """
    Internal recursive RBFS.
    Returns (result_path_or_None, new_f_limit).
    """
    f = g + heuristic(node, goal)
    if f > f_limit:
        return None, f

    if node == goal:
        return path, f

    neighbors = WEIGHTED_GRAPH.get(node, [])
    if not neighbors:
        return None, _RBFS_INF

    # Build successors sorted by f-value
    successors = []
    for nb, cost in neighbors:
        if nb not in path:  # avoid cycles
            nb_g = g + cost
            nb_f = nb_g + heuristic(nb, goal)
            successors.append((nb_f, nb_g, nb))
    successors.sort()

    while successors:
        counter[0] += 1
        best_f, best_g, best_node = successors[0]
        if best_f > f_limit:
            return None, best_f
        alternative = successors[1][0] if len(successors) > 1 else _RBFS_INF
        result, new_f = _rbfs_inner(best_node, goal, best_g,
                                    min(f_limit, alternative),
                                    path + [best_node], counter)
        successors[0] = (new_f, best_g, best_node)
        successors.sort()
        if result is not None:
            return result, new_f

    return None, _RBFS_INF


def rbfs(source: str, goal: str) -> dict:
    """
    Recursive Best-First Search.
    Memory-efficient alternative to A*.
    """
    counter = [0]
    result, _ = _rbfs_inner(source, goal, 0, _RBFS_INF, [source], counter)
    if result:
        # Compute cost by summing edges
        cost = 0
        for i in range(len(result) - 1):
            for nb, c in WEIGHTED_GRAPH.get(result[i], []):
                if nb == result[i + 1]:
                    cost += c
                    break
        return {"path": result, "cost": cost,
                "steps": len(result) - 1, "nodes_expanded": counter[0]}
    return {"path": [], "cost": -1, "steps": -1, "nodes_expanded": counter[0]}


# ────────────────────────────────────────────────────────────────────────────
#  Main public API
# ────────────────────────────────────────────────────────────────────────────

def run_search(source: str, goal: str, graph_type: str = "weighted",
               algorithm: str = "auto", compare: bool = False) -> dict:
    """
    Main entry point for the Search & Navigation module.

    Parameters:
        source     (str): Starting campus node.
        goal       (str): Destination campus node.
        graph_type (str): 'weighted' or 'unweighted'.
        algorithm  (str): Force a specific algorithm or 'auto'.
        compare    (bool): If True, also run comparison algorithms.

    Returns:
        dict: Search output following standard template.
    """
    if not source or not goal:
        return {"algorithm_used": "None", "path": [],
                "cost": -1, "steps": -1,
                "error": "Source or destination not provided."}

    if source == goal:
        return {"algorithm_used": "None", "path": [source],
                "cost": 0, "steps": 0}

    # Choose operational algorithm
    if algorithm != "auto":
        algo_name = algorithm
    elif graph_type == "unweighted":
        algo_name = "BFS"
    else:
        algo_name = "A*"

    algo_map = {
        "BFS":    lambda: bfs(source, goal),
        "DFS":    lambda: dfs(source, goal),
        "DLS":    lambda: dls(source, goal),
        "IDS":    lambda: ids(source, goal),
        "UCS":    lambda: ucs(source, goal),
        "BiBFS":  lambda: bidirectional_bfs(source, goal),
        "Greedy": lambda: greedy_bfs(source, goal),
        "A*":     lambda: astar(source, goal),
        "RBFS":   lambda: rbfs(source, goal),
    }

    if algo_name not in algo_map:
        algo_name = "A*"

    primary = algo_map[algo_name]()
    output  = {
        "algorithm_used": algo_name,
        "path":           primary["path"],
        "cost":           primary["cost"],
        "steps":          primary["steps"],
        "nodes_expanded": primary.get("nodes_expanded", 0),
    }

    if compare:
        comparisons = {}
        for name, fn in algo_map.items():
            if name != algo_name:
                try:
                    r = fn()
                    comparisons[name] = {
                        "path":           r["path"],
                        "cost":           r["cost"],
                        "steps":          r["steps"],
                        "nodes_expanded": r.get("nodes_expanded", 0),
                    }
                except Exception:
                    comparisons[name] = {"error": "Algorithm failed."}
        output["comparisons"] = comparisons

    return output


def display_search_output(search_output: dict, show_comparisons: bool = False) -> None:
    """Print search results in human-readable format."""
    print("\n" + "-" * 50)
    print("  SEARCH & NAVIGATION RESULT")
    print("-" * 50)

    if search_output.get("error"):
        print(f"  [!] Error: {search_output['error']}")
        print("-" * 50)
        return

    if not search_output["path"]:
        print("  [!] No path found between source and destination.")
        print("-" * 50)
        return

    print(f"  Algorithm     : {search_output['algorithm_used']}")
    print(f"  Path          : {' → '.join(search_output['path'])}")
    print(f"  Cost          : {search_output['cost']}")
    print(f"  Steps         : {search_output['steps']}")
    print(f"  Nodes Expanded: {search_output.get('nodes_expanded', 'N/A')}")

    if show_comparisons and "comparisons" in search_output:
        print("\n  Comparison with other algorithms:")
        print(f"  {'Algorithm':<12} {'Cost':>6}  {'Steps':>6}  {'Expanded':>10}  Path")
        print("  " + "-" * 65)
        # Show primary first
        alg = search_output["algorithm_used"]
        print(f"  {alg:<12} {search_output['cost']:>6}  "
              f"{search_output['steps']:>6}  "
              f"{search_output.get('nodes_expanded', 0):>10}  "
              f"{' → '.join(search_output['path'])}")
        for name, res in search_output["comparisons"].items():
            if "error" in res:
                print(f"  {name:<12}  (failed)")
            elif res["path"]:
                print(f"  {name:<12} {res['cost']:>6}  "
                      f"{res['steps']:>6}  "
                      f"{res.get('nodes_expanded', 0):>10}  "
                      f"{' → '.join(res['path'])}")
            else:
                print(f"  {name:<12}  No path found")
    print("-" * 50)

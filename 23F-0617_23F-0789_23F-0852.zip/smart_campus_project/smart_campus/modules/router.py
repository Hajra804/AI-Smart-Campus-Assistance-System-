"""
============================================================
Module: router.py
Author: Smart Campus AI System
Description:
    Request Router Module for the Smart Campus AI Decision
    Support and Automation System.

    Responsibilities:
    - Read the standardized request object from preprocessing
    - Determine the correct pipeline based on request_type
    - Produce a router control object listing which modules to run
    - Does NOT solve the request itself; only directs the flow
============================================================
"""


def route_request(request: dict) -> dict:
    """
    Inspect the request_type field and decide which modules to execute.

    Parameters:
        request (dict): Standardized request object from preprocessing.

    Returns:
        dict: Router control object with pipeline and flags.
    """
    request_type = request.get("request_type", "")

    # Default all flags to False
    needs_ann    = False
    needs_logic  = False
    needs_csp    = False
    needs_search = False
    pipeline     = []

    if request_type == "Navigation_Only":
        pipeline     = ["Search"]
        needs_search = True

    elif request_type == "Eligibility_Check":
        pipeline    = ["Logic_KB"]
        needs_logic = True

    elif request_type == "Booking_or_Scheduling":
        pipeline    = ["Logic_KB", "CSP"]
        needs_logic = True
        needs_csp   = True
        # Search is optional – include if user provided a location
        if request.get("current_location"):
            pipeline.append("Search")
            needs_search = True

    elif request_type == "Urgent_Service_Request":
        pipeline     = ["ANN", "Logic_KB", "CSP"]
        needs_ann    = True
        needs_logic  = True
        needs_csp    = True
        if request.get("current_location"):
            pipeline.append("Search")
            needs_search = True

    elif request_type == "Full_Service_Request":
        pipeline     = ["ANN", "Logic_KB", "CSP", "Search"]
        needs_ann    = True
        needs_logic  = True
        needs_csp    = True
        needs_search = True

    else:
        # Unknown request type – reject immediately
        pipeline = []

    router_output = {
        "request_id":      request.get("request_id", ""),
        "selected_pipeline": pipeline,
        "needs_ann":       needs_ann,
        "needs_logic":     needs_logic,
        "needs_csp":       needs_csp,
        "needs_search":    needs_search,
        "valid":           bool(pipeline),
    }

    return router_output


def display_router_output(router_output: dict) -> None:
    """
    Print the router decision in a human-readable format.
    """
    print("\n" + "-" * 50)
    print("  REQUEST ROUTER DECISION")
    print("-" * 50)
    if not router_output["valid"]:
        print("  [!] Unknown request type. Request rejected by router.")
        return
    print(f"  Request ID : {router_output['request_id']}")
    print(f"  Pipeline   : {' → '.join(router_output['selected_pipeline'])}")
    print(f"  ANN        : {'Yes' if router_output['needs_ann'] else 'No'}")
    print(f"  Logic/KB   : {'Yes' if router_output['needs_logic'] else 'No'}")
    print(f"  CSP        : {'Yes' if router_output['needs_csp'] else 'No'}")
    print(f"  Search     : {'Yes' if router_output['needs_search'] else 'No'}")
    print("-" * 50)

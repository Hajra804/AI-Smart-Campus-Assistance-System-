"""
============================================================
Module: csp_scheduler.py
Author: Smart Campus AI System
Description:
    CSP (Constraint Satisfaction Problem) Scheduler Module
    for the Smart Campus AI Decision Support and Automation System.

    Responsibilities:
    - Assign slots, rooms, or support resources under constraints
    - Enforce hard constraints: no slot clash, examiner clash,
      supervisor clash, and group precedence
    - Use backtracking with forward checking
    - Return a conflict-free assignment or an informative failure

    Variables : Groups G1–G6 (or students per category)
    Domains   : Slots {1, 2, 3, 4}
    Constraints:
        - No two groups share the same slot (≠ constraint)
        - Examiner cannot supervise two groups at same slot
        - Supervisor cannot supervise two groups at same slot
        - G3 must be scheduled after G4 (precedence)
============================================================
"""

import copy

# ── Room definitions per category ───────────────────────────────────────────
CATEGORY_ROOMS = {
    "AI_Lab_Support":  "AI_Lab",
    "Viva_Scheduling": "Exam_Hall",
    "Access_Request":  "Admin_Block",
    "Maintenance":     "Science_Block",
    "Emergency_Help":  "Medical_Center",
}

# ── Default slot domain ──────────────────────────────────────────────────────
ALL_SLOTS = [1, 2, 3, 4]

# ── Simulated current bookings (persists within a session) ───────────────────
# Maps (room, slot) -> group_id  (occupied bookings)
_current_bookings: dict = {}

# ── Group definitions for Viva scheduling ───────────────────────────────────
# Each group: {'examiner': str, 'supervisor': str}
_default_groups = {
    "G1": {"examiner": "E1", "supervisor": "S1"},
    "G2": {"examiner": "E2", "supervisor": "S2"},
    "G3": {"examiner": "E1", "supervisor": "S3"},   # same examiner as G1
    "G4": {"examiner": "E3", "supervisor": "S1"},   # same supervisor as G1
    "G5": {"examiner": "E2", "supervisor": "S2"},   # same examiner+supervisor as G2
    "G6": {"examiner": "E3", "supervisor": "S3"},
}


# ────────────────────────────────────────────────────────────────────────────
#  Simple single-request scheduler
# ────────────────────────────────────────────────────────────────────────────

def _is_slot_free(room: str, slot: int) -> bool:
    """Check whether (room, slot) is currently unbooked."""
    return (room, slot) not in _current_bookings


def _book_slot(room: str, slot: int, identifier: str):
    """Mark a (room, slot) as booked by identifier."""
    _current_bookings[(room, slot)] = identifier


def assign_slot(request: dict) -> dict:
    """
    Find the best available slot for a single-user request.
    Tries preferred_slot first, then falls back to next free slot.

    Parameters:
        request (dict): Standardized request object.

    Returns:
        dict: CSP assignment result.
    """
    name       = request.get("name", "Unknown")
    category   = request.get("category", "AI_Lab_Support")
    pref_slot  = request.get("preferred_slot", 1)
    room       = CATEGORY_ROOMS.get(category, "AI_Lab")

    # Build slot order: preferred first, then remaining in order
    ordered_slots = [pref_slot] + [s for s in ALL_SLOTS if s != pref_slot]

    notes = ""
    for slot in ordered_slots:
        if _is_slot_free(room, slot):
            _book_slot(room, slot, name)
            if slot != pref_slot:
                notes = (f"Preferred slot {pref_slot} was unavailable. "
                         f"Slot {slot} is the next feasible conflict-free assignment.")
            else:
                notes = f"Preferred slot {pref_slot} was successfully assigned."
            return {
                "decision":      "accepted",
                "assigned_room": room,
                "assigned_slot": slot,
                "destination":   room,
                "notes":         notes,
            }

    return {
        "decision":      "rejected",
        "assigned_room": "",
        "assigned_slot": None,
        "destination":   "",
        "notes":         f"No available slots in {room}. All slots are occupied.",
    }


# ────────────────────────────────────────────────────────────────────────────
#  Full CSP backtracking for Viva scheduling (multi-group)
# ────────────────────────────────────────────────────────────────────────────

def _is_consistent(assignments: dict, group: str, slot: int, groups: dict) -> bool:
    """
    Check whether assigning slot to group is consistent with current assignments.
    Constraints:
        1. No two groups share the same slot
        2. No examiner clash (same examiner, same slot)
        3. No supervisor clash (same supervisor, same slot)
        4. G4 < G3 (precedence: G3 after G4)
    """
    g_data = groups[group]

    for assigned_group, assigned_slot in assignments.items():
        a_data = groups[assigned_group]

        # Constraint 1: slot clash
        if assigned_slot == slot:
            return False

        # Constraint 2: examiner clash
        if a_data["examiner"] == g_data["examiner"] and assigned_slot == slot:
            return False

        # Constraint 3: supervisor clash
        if a_data["supervisor"] == g_data["supervisor"] and assigned_slot == slot:
            return False

    # Constraint 4: G4 precedence (G3 must come after G4)
    if group == "G3" and "G4" in assignments:
        if slot <= assignments["G4"]:
            return False
    if group == "G4" and "G3" in assignments:
        if slot >= assignments["G3"]:
            return False

    return True


def _backtrack(assignments: dict, unassigned: list,
               domains: dict, groups: dict) -> dict | None:
    """
    Recursive backtracking CSP solver.
    Returns complete assignment dict or None if no solution found.
    """
    if not unassigned:
        return assignments  # All variables assigned

    group = unassigned[0]
    remaining = unassigned[1:]

    for slot in domains[group]:
        if _is_consistent(assignments, group, slot, groups):
            new_assignments = copy.copy(assignments)
            new_assignments[group] = slot
            result = _backtrack(new_assignments, remaining, domains, groups)
            if result is not None:
                return result

    return None  # Backtrack


def solve_viva_csp(group_ids: list = None) -> dict:
    """
    Solve the Viva scheduling CSP for the given group IDs.
    If no group_ids given, solves for all default groups.

    Parameters:
        group_ids (list): Optional list of group IDs to schedule.

    Returns:
        dict: {
            'decision'  : 'accepted' / 'rejected',
            'schedule'  : {group: slot},
            'notes'     : str
        }
    """
    if group_ids is None:
        group_ids = list(_default_groups.keys())

    groups = {gid: _default_groups[gid] for gid in group_ids if gid in _default_groups}
    if not groups:
        return {
            "decision": "rejected",
            "schedule": {},
            "notes":    "No valid groups found in the provided group IDs."
        }

    # Initial domains: all slots available for each group
    domains = {g: list(ALL_SLOTS) for g in groups}

    solution = _backtrack({}, list(groups.keys()), domains, groups)

    if solution:
        return {
            "decision": "accepted",
            "schedule": solution,
            "notes":    f"Conflict-free viva schedule found for {len(solution)} groups."
        }
    return {
        "decision": "rejected",
        "schedule": {},
        "notes":    "No feasible viva schedule exists given the constraints."
    }


# ────────────────────────────────────────────────────────────────────────────
#  Main public API
# ────────────────────────────────────────────────────────────────────────────

def run_csp(request: dict) -> dict:
    """
    Main entry point for the CSP Scheduler module.
    Chooses between single-user slot assignment and
    group-based viva CSP depending on category.

    Parameters:
        request (dict): Standardized request object.

    Returns:
        dict: CSP output following standard template.
    """
    category = request.get("category", "AI_Lab_Support")
    group_id = request.get("group_id", "")

    if category == "Viva_Scheduling":
        # If a specific group provided, schedule that; else all groups
        if group_id:
            groups_to_schedule = [g.strip() for g in group_id.split(",") if g.strip()]
        else:
            groups_to_schedule = list(_default_groups.keys())

        viva_result = solve_viva_csp(groups_to_schedule)

        # For the current user, extract their assigned slot from schedule
        assigned_slot = None
        schedule = viva_result.get("schedule", {})
        if schedule:
            assigned_slot = list(schedule.values())[0]

        room = CATEGORY_ROOMS.get(category, "Exam_Hall")
        return {
            "decision":      viva_result["decision"],
            "assigned_room": room if viva_result["decision"] == "accepted" else "",
            "assigned_slot": assigned_slot,
            "destination":   room if viva_result["decision"] == "accepted" else "",
            "notes":         viva_result["notes"],
            "full_schedule": schedule,
        }

    else:
        return assign_slot(request)


def display_csp_output(csp_output: dict) -> None:
    """Print CSP results in human-readable format."""
    print("\n" + "-" * 50)
    print("  CSP SCHEDULER RESULT")
    print("-" * 50)
    status = "ACCEPTED ✓" if csp_output["decision"] == "accepted" else "REJECTED ✗"
    print(f"  Decision      : {status}")
    if csp_output["decision"] == "accepted":
        print(f"  Assigned Room : {csp_output['assigned_room']}")
        print(f"  Assigned Slot : {csp_output['assigned_slot']}")
        print(f"  Destination   : {csp_output['destination']}")
    print(f"  Notes         : {csp_output['notes']}")
    if csp_output.get("full_schedule"):
        print("  Full Viva Schedule:")
        for grp, slot in csp_output["full_schedule"].items():
            print(f"    {grp} → Slot {slot}")
    print("-" * 50)
